Reverdo press kit - Kaotic Production
https://kaoticproduction.com/reverdo/presskit/

All screenshots and art are taken from the game (1.27-1.28).
You may use them to write about Reverdo. Please do not alter the logos.
